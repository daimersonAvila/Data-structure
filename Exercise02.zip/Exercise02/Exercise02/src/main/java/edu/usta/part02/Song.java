package edu.usta.part02;

import java.util.Objects;

public class Song {
   private int cod;
   private String Name;
   private String artist;
   private Integer duration;

    public Song() {
    }

    public Song(int cod, String Name, String artist, Integer duration) {
        this.cod = cod;
        this.Name = Name;
        this.artist = artist;
        this.duration = duration;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.cod;
        hash = 71 * hash + Objects.hashCode(this.Name);
        hash = 71 * hash + Objects.hashCode(this.artist);
        hash = 71 * hash + Objects.hashCode(this.duration);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Song other = (Song) obj;
        if (this.cod != other.cod) {
            return false;
        }
        if (!Objects.equals(this.Name, other.Name)) {
            return false;
        }
        if (!Objects.equals(this.artist, other.artist)) {
            return false;
        }
        return Objects.equals(this.duration, other.duration);
    }

    @Override
    public String toString() {
        return "Song{" + "cod=" + cod + ", Name=" + Name + ", artist=" + artist + ", duration=" + duration + '}';
    }
    
  
    /**
     * Attributes of the class Song:
     * - cod: The code of the song
     * - name: The name of the song
     * - artist: The artist of the song
     * - duration: The duration of the song
     * 
     * Methods of the class Song:
     * - Constructor without parameters
     * - Constructor with parameters
     * - Getters and setters for all attributes
     * - hashCode
     * - equals
     * - toString
     */

    // Insert Code Here
}
