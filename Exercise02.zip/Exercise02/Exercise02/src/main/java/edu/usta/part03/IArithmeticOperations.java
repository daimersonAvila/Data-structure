package edu.usta.part03;

public interface IArithmeticOperations {
    public int add(int a, int b);

    public int divide(int a, int b);

    public boolean isPrime(int a);

    public int amountOfLetters(String text);
}
