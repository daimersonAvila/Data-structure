package edu.usta.part03;

public class ArithmeticOperationsImplementation implements IArithmeticOperations {

    @Override
    public int add(int a, int b) {
        return a + b;
    }

    @Override
    public int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        return a / b;
    }

    @Override
    public boolean isPrime(int a) {
        if (a < 2) {
            return false; // 0 and 1 are not prime numbers
        }
        for (int i = 2; i * i <= a; i++) { // loop from 2 to the square root of 'a'
            if (a % i == 0) {
                return false; // 'a' is divisible by 'i', so it's not prime
            }
        }
        return true; // 'a' is prime
    }

    @Override
    public int amountOfLetters(String text) {
        return text.length();
    }

    // Additional methods can be implemented here
}
