package edu.usta.part04;

public class TV extends Appliance {
    private Integer Inches;

    public TV() {
    }

    public TV(Integer Inches) {
        this.Inches = Inches;
    }

    public TV(Integer Inches, int cod, String brand, double value, String amount) {
        super(cod, brand, value, amount);
        this.Inches = Inches;
    }

    public Integer getInches() {
        return Inches;
    }

    public void setInches(Integer Inches) {
        this.Inches = Inches;
    }

    @Override
    public String toString() {
        return "TV{" + "Inches=" + Inches + '}';
    }
    
    /**
     * Inherits from Appliance
     * 
     * Attributes of the TV class:
     * - inches: Integer
     * 
     * Methods of the TV class:
     * - Constructor without parameters
     * - Constructor with parameters
     * - Getters and Setters
     * - toString
     */

    // Insert Code Here
}
