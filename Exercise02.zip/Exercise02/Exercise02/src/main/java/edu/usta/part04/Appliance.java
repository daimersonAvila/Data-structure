package edu.usta.part04;

public class Appliance {
   private int cod;
    private String brand;   
    private double value;
    private String amount;
    public Appliance() {
    }
    public Appliance(int cod, String brand, double value, String amount) {
        this.cod = cod;
        this.brand = brand;
        this.value = value;
        this.amount = amount;
    }
    public int getCod() {
        return cod;
    }
    public void setCod(int cod) {
        this.cod = cod;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public double getValue() {
        return value;
    }
    public void setValue(double value) {
        this.value = value;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    @Override
    public String toString() {
        return "Appliance [cod=" + cod + ", brand=" + brand + ", value=" + value + ", amount=" + amount + "]";
    }
    

    /**
     * Attributes of the Appliance class:
     * - cod: Integer
     * - brand: String
     * - value: Double
     * - amount: String
     *
     * Methods of the Appliance class:
     * - Constructor without parameters
     * - Constructor with parameters
     * - Getters and Setters
     * - hashCode
     * - equals
     * - toString
     */

    // Insert Code Here
}
