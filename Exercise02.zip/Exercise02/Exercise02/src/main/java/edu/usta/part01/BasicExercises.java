package edu.usta.part01;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BasicExercises {

    /**
     * Create a function that receives a string and returns the number of characters
     * in the string.
     * 
     * @param text The string to count the characters
     * @return The number of characters in the string
     */
    public int countCharacters(String text) {
        if (text == null) {
            return 0; // Return 0 for null input to avoid NullPointerException
        }
        return text.length(); // Returns the length of the string
    }

    /**
     * Create a function that receives three integers and returns the largest
     * number.
     * 
     * @param a The first number
     * @param b The second number
     * @param c The third number
     * @return The largest number
     */
    public int getLargestNumber(int a, int b, int c) {
        return Math.max(a, Math.max(b, c)); // Returns the largest of the three numbers
    }

    /**
     * Create a function that receives a string and returns the string in uppercase.
     * 
     * @param text The string to convert to uppercase
     * @return The string in uppercase
     */
    public String toUpperCase(String text) {
        return text.toUpperCase();
    }

    /**
     * Create a function that receives an int n and returns a vector with size n,
     * the values by the vector are random numbers between 100 and 500.
     * 
     * @param n The size of the vector
     * @return A vector with random numbers between 100 and 500
     */
    public List<Integer> getRandomVectorForNWithRange(int n) {
        List<Integer> randomNumbers = new ArrayList<>();
        Random rand = new Random();

        for (int i = 0; i < n; i++) {
            int randomValue = rand.nextInt(401) + 100; // Random number between 100 and 500
            randomNumbers.add(randomValue);
        }

        return randomNumbers;
    }

    public static void main(String[] args) {
        BasicExercises exercises = new BasicExercises();

        // Example usage of countCharacters
        String exampleText = "Hello, world!";
        System.out.println("Number of characters: " + exercises.countCharacters(exampleText));

        // Example usage of getLargestNumber
        int largest = exercises.getLargestNumber(10, 20, 15);
        System.out.println("Largest number: " + largest);

        // Example usage of toUpperCase
        String upperText = exercises.toUpperCase("hello");
        System.out.println("Uppercase string: " + upperText);

        // Example usage of getRandomVectorForNWithRange
        List<Integer> randomVector = exercises.getRandomVectorForNWithRange(5);
        System.out.println("Random vector: " + randomVector);
    }
}
