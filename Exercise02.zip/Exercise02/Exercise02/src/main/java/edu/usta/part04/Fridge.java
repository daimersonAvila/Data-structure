package edu.usta.part04;

public class Fridge extends Appliance {
    private Integer capacity;

    public Fridge() {
    }

    public Fridge(Integer capacity) {
        this.capacity = capacity;
    }

    public Fridge(Integer capacity, int cod, String brand, double value, String amount) {
        super(cod, brand, value, amount);
        this.capacity = capacity;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Fridge{" + "capacity=" + capacity + '}';
    }
    
    
    /**
     * Inherits from Appliance
     * 
     * Attributes of the Fridge class:
     * - capacity: Integer
     * 
     * Methods of the Fridge class:
     * - Constructor without parameters
     * - Constructor with parameters
     * - Getters and Setters
     * - toString
     */

    // Insert Code Here
}
