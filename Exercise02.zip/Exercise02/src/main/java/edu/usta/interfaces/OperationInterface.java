/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.usta.interfaces;

/**
 *
 * @author Smith
 */
public interface OperationInterface {
    // crear arreglo de strings randoms con un tamaño especificado por un rango

    /**
     *
     * @param minSize tamaño mínimo array
     * @param maxSize tamaño máximo array
     * @param charCount Número de caracteres de cada string
     */
    public void createRandomArray(int minSize, int maxSize, int charCount);

    /**
     * añade un elemnto en una posicion específica de array
     *
     * @param position Indíce donde el elemento será insertado
     * @param value valor en tipo cadena de texto que será añadido
     */
    public void addElementAt(int position, String value);

    /**
     * añade un elemnto al final del array
     *
     * @param value valor en tipo cadena de texto que será añadido
     */
    public void addElement(String value);

    /**
     * Inserte un elemento en una posicionn especificas moviendo otros items si
     * ses necesario
     *
     * @param position Indíce donde el elemento será insertado
     * @param value valor en tipo cadena de texto que será añadido
     */
    public void insertElementAt(int position, String value);

    /**
     * actualiza el valor de el elemento en una posicion dada
     *
     * @param position Indíce donde el elemento será actualizada
     * @param newvalue valor en tipo cadena de texto que será actualizada
     */
    public void editElemen(int position, String newvalue);
//limpia todos los elementos de el array 

    public void clearArray();

    /**
     * retorna el elemnto del array
     *
     * @retur Número de elementos del array
     */
    public int getSize();
}
