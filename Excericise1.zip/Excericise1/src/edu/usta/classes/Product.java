/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.usta.classes;

import java.util.Objects;

/**
 *
 * @author sebastian
 */
public class Product {
    private Integer codProduct;
    private String nameProduct;
    private Brand brandProduct;
    private Double valueProduct;
    private Integer amountProduct;

    public Product() {
    }

    public Product(Integer codProduct, String nameProduct, Brand brandProduct, Double valueProduct, Integer amountProduct) {
        this.codProduct = codProduct;
        this.nameProduct = nameProduct;
        this.brandProduct = brandProduct;
        this.valueProduct = valueProduct;
        this.amountProduct = amountProduct;
    }
    public Integer getCodProduct() {
        return codProduct;
    }

    public void setCodProduct(Integer codProduct) {
        this.codProduct = codProduct;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public Brand getBrandProduct() {
        return brandProduct;
    }

    public void setBrandProduct(Brand brandProduct) {
        this.brandProduct = brandProduct;
    }

    public Double getValueProduct() {
        return valueProduct;
    }

    public void setValueProduct(Double valueProduct) {
        this.valueProduct = valueProduct;
    }

    public Integer getAmountProduct() {
        return amountProduct;
    }

    public void setAmountProduct(Integer amountProduct) {
        this.amountProduct = amountProduct;
    }

    @Override
    public String toString() {
        return "Product{" + "codProduct=" + codProduct + ", nameProduct=" + nameProduct + ", brandProduct=" + brandProduct + ", valueProduct=" + valueProduct + ", amountProduct=" + amountProduct + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.codProduct);
        hash = 59 * hash + Objects.hashCode(this.nameProduct);
        hash = 59 * hash + Objects.hashCode(this.brandProduct);
        hash = 59 * hash + Objects.hashCode(this.valueProduct);
        hash = 59 * hash + Objects.hashCode(this.amountProduct);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product other = (Product) obj;
        if (!Objects.equals(this.nameProduct, other.nameProduct)) {
            return false;
        }
        if (!Objects.equals(this.brandProduct, other.brandProduct)) {
            return false;
        }
        if (!Objects.equals(this.codProduct, other.codProduct)) {
            return false;
        }
        if (!Objects.equals(this.valueProduct, other.valueProduct)) {
            return false;
        }
        return Objects.equals(this.amountProduct, other.amountProduct);
    }

}


