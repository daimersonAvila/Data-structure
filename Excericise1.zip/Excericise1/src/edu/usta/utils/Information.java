/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.usta.utils;

import edu.usta.classes.Brand;

/**
 *
 * @author Estudiante
 */
public class Information {
    public static Brand[] generateBrands(){
        Brand[] brands = new Brand[5];
        brands[0] = new Brand(1, "Adidas");
        brands[1] = new Brand(2, "Nike");
        brands[2] = new Brand(3, "Gucci");
        brands[3] = new Brand(4, "Prada");
        brands[4] = new Brand(5, "Prada");
        return brands;
    }  
}
